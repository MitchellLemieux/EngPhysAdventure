Readme How to Run the game
1. Run the shortcut on your desktop or where it was installed
2. Enjoy!
3. Give feedback: https://goo.gl/forms/OEMQCupWvEtibd0E3
4. Report any pesky bugs: https://goo.gl/forms/Jo6P7oMj86OiLvE63
Thanks for playing!

    	                   A____ ________
    	                   /_  H|\_____  \ 
    	                    |  O|  ___|  |
    	                    |  L| /___   <
    	                    |  L|  ___\   |
     	                    |  Y| /W O O D|
    	                    |___|/________/
  	                      Production

Version: Alpha v0.30 - The FINAL EPTA UPDATE
Updated: November 21st, 2019
